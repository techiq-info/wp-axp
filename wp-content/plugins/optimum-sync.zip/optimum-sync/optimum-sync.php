<?php 
defined( 'ABSPATH' ) or die( 'Nope, not accessing this' );
/**
 * Plugin Name: Optimum Products Sync
 * Plugin URI:  http://myoctopus.co.il/
 * Description: Syncronising the data like Products, Ordres, Customers from api of http://myoctopus.co.il/ to woocommrece
 * Version:     1.0.0
 * Author:      Octopus Web
 * Author URI:  http://myoctopus.co.il/
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

class OptimumOctopus_WoocommerceSync {

	private $optimum_api_table = 'optimum_api_table';
	
	function __construct(){
		//error_reporting(E_ALL);
		//ini_set('display_errors',1);
		ini_set('memory_limit','16M');

		add_action('wp_ajax_getOptimumProducts', array($this, 'getProducts'));
		add_action('wp_ajax_nopriv_getOptimumProducts', array($this, 'getProducts'));

		add_action('wp_ajax_getOptimumProductsCategory', array($this, 'getProductsCategory'));
		add_action('wp_ajax_nopriv_getOptimumProductsCategory', array($this, 'getProductsCategory'));

		add_action('wp_ajax_getOptimumProductsSubCategory', array($this, 'getProductsSubCategory'));
		add_action('wp_ajax_nopriv_getOptimumProductsSubCategory', array($this, 'getProductsSubCategory'));

		add_action('woocommerce_thankyou', array($this, 'getProductUpdateOrderShort'));
		add_action('woocommerce_thankyou', array($this, 'getProductUpdateOrderShort'));

		add_action('wp_ajax_nopriv_attach_product_thumbnail', array($this, 'attach_product_thumbnail'));
		if ( is_admin() ) {
            register_activation_hook(__FILE__, array($this,'activate'));

            register_deactivation_hook(__FILE__, array($this,'remove_database'));
        }
	}

	public function getProducts(){

		$data = array(
			'id_Customer_Optimum' => 2500,
			'enter_user_Optimum' => 'zaidman1',
			'enter_pass_Optimum' => 'zaidman1',
			'type' => 'full'
		);
		
		$limit = $_GET['limit'];
		$page = $_GET['page'];
		$i = ($page - 1)*$limit;
		$offset = ($i+$limit) - 1;
		//exit("test");
		$dataXml = $this->generateRequestContext('items_ordrs_export', $data);
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://myoctopus.co.il/octopus_web/Web_service/WebService_Order.asmx/items_ordrs_export?id_Customer_Optimum=2500&enter_user_Optimum=zaidman1&enter_pass_Optimum=zaidman1&type=full",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_POSTFIELDS => $dataXml,
		  CURLOPT_HTTPHEADER => array(
		    "Content-Type: text/xml"
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$arrData = simplexml_load_string($response) or die("Error: Cannot create object");
		$con = json_encode($arrData); 
		$newArr = json_decode($con, true);
		/*echo "<pre>";
		print_r($newArr);
		exit("testing");*/
		//$startpoint = $this->checkStartpointIdExists();

		if(isset($newArr) && !empty($newArr)) {
			$productsAdded = 0;
			$productsUpdated = 0;
			$total_products = count($newArr['items_export']);
			$cnt = 0;

			//$pagi_offset = ($startpoint['page'] - 1)*$limit;

			//$startpoint = $this->insertStartpointId( $startpoint['page'], $startpoint['startpoint'] );
				
			foreach ($newArr['items_export'] as $key => $val1) {
				if($cnt >= $i && $cnt <= $offset){
					if(!$this->checkProductByMetaData('_id_Barcod', $val1['id_Barcod'])){
						$post_id = $this->create_products($val1);
						$productsAdded++;
					}else{
						$post_id = $this->checkProductByMetaData('_id_Barcod', $val1['id_Barcod']);
						$productsUpdated++;
					}
					$this->UpdateProductMetas($post_id, $val1);
					
					// map with category
					$parent_term_id = $this->checkIftermExistsByMetaValue('id_Departments', $val1['id_Department'] );
					$child_term_id = $this->checkIftermExistsByMetaValue('id_Group', $val1['id_Group'] );
					
					$terms = array( $parent_term_id, $child_term_id );

					wp_set_post_terms( $post_id, $terms, 'product_cat' );

					$url = "http://ok-rsoft.com/Proxy/Optimum_Orders/Content/ProductsImages/1000/".$val1['name_picture'];
					$this->Generate_Featured_Image($url, $post_id);
				}
				$cnt++;
			}
		}
		echo json_encode( array('result' => true, 'msg' => $productsAdded.' products created and '.$productsUpdated.' products updated') );
		exit();
	}

	public function getProductsCategory() {

		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://myoctopus.co.il/octopus_web/Web_service/WebService_Order.asmx/Departments_ordrs_export?id_Customer_Optimum=2500&enter_user_Optimum=zaidman1&enter_pass_Optimum=zaidman1",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		//  CURLOPT_POSTFIELDS => $dataXml,
		  CURLOPT_HTTPHEADER => array(
		    "Content-Type: text/xml"
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$arrData = simplexml_load_string($response) or die("Error: Cannot create object");
		$con = json_encode($arrData); 
		$newArr = json_decode($con, true);
		/*echo "<pre>";
		print_r($newArr);
		exit("productcate");*/

		if( isset($newArr) && !empty($newArr) ) {
			foreach ($newArr['Departments_export'] as $key => $value) {
				// insert product_cat
				$tax_insert_id = wp_insert_term( $value['name_Departments'],'product_cat' );
				# add term meta field
				if( isset($tax_insert_id->error_data['term_exists']) && !empty($tax_insert_id->error_data['term_exists']) ) {
					$term_id = $tax_insert_id->error_data['term_exists'];
					update_term_meta( $term_id, "id_Departments", $value['id_Departments'] );
				} else {
					add_term_meta( $tax_insert_id['term_taxonomy_id'], "id_Departments", $value['id_Departments'], false );	
				}
				/*echo "<pre>";
				print_r($tax_insert_id);
				echo $value['id_Departments'];
				echo $tax_insert_id['term_taxonomy_id'];
				exit;*/
			}
			echo json_encode( array('result' => true, 'msg' => 'products category created.') );
			exit();
		}
	}

	public function getProductsSubCategory() { 
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://myoctopus.co.il/octopus_web/Web_service/WebService_Order.asmx/Grups_ordrs_export?id_Customer_Optimum=2500&enter_user_Optimum=zaidman1&enter_pass_Optimum=zaidman1",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		//  CURLOPT_POSTFIELDS => $dataXml,
		  CURLOPT_HTTPHEADER => array(
		    "Content-Type: text/xml"
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$arrData = simplexml_load_string($response) or die("Error: Cannot create object");
		$con = json_encode($arrData); 
		$newArr = json_decode($con, true);
		/*echo "<pre>";
		print_r($newArr);
		exit("productsubcate");*/

		if( isset($newArr) && !empty($newArr) ) {
			foreach ($newArr['Groups_export'] as $key => $value) {
				$parent_term_id = $this->checkIftermExistsByMetaValue('id_Departments', $value['Attribution_Department']);
				if( isset($parent_term_id) && !empty($parent_term_id) ) {
					$term_id = wp_insert_term( $value['name_Group'], 'product_cat', array('parent' => $parent_term_id) );
					if( isset($term_id->error_data['term_exists']) && !empty($term_id->error_data['term_exists']) ) {
						$uterm_id = $term_id->error_data['term_exists'];
						update_term_meta( $uterm_id, "id_Group", $value['id_Group'] );
					} else {
						add_term_meta( $term_id['term_taxonomy_id'], "id_Group", $value['id_Group'], false );	
					}
				}
			}
		}
		echo json_encode( array('result' => true, 'msg' => 'products Sub category created.') );
		exit();
	}

	public function checkIftermExistsByMetaValue($meta_key = '', $meta_value = '') {
		if($meta_key != '' && $meta_value != '') {
			$args = array(
			    'taxonomy'   => 'product_cat',
			    'hide_empty' => false,
			    'meta_query' => array(
			         array(
			            'key'       => $meta_key,
			            'value'     => $meta_value,
			            'compare'   => '='
			         )
			    )
			);
			
			$terms = get_terms( $args );
			
			/*echo "<pre>";
			print_r($terms);
			exit("test11");*/
			
			if(!empty($terms)){
				return $terms[0]->term_id;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public function activate(){
		global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        /*if ($wpdb->get_var("show tables like '" . $wpdb->prefix . $this->optimum_api_table . "'") != $wpdb->prefix . $this->optimum_api_table)
        {
            $sql = "CREATE TABLE " . $wpdb->prefix . $this->optimum_api_table . " (
				`id` mediumint(9) NOT NULL AUTO_INCREMENT,
				`startpoint` mediumint(9) NOT NULL,
				`page` mediumint(9) NOT NULL,
				PRIMARY KEY (id)
				)$charset_collate;";

            require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }*/
	}


	public function remove_database(){
		global $wpdb;
        $table_name = $wpdb->prefix . $this->optimum_api_table;
        $sql = "DROP TABLE IF EXISTS $table_name";
        $wpdb->query($sql);
	}

	public function insertStartpointId($page,$startpoint) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->optimum_api_table;
        $sql = $wpdb->prepare("INSERT INTO  `$table_name` VALUES (NULL, %s, %s)", $page, $startpoint );
        $sqlres = $wpdb->query($sql);
        /*echo "<pre>";
        print_r($sqlres);
        exit("insert11");*/
    }

    public function checkStartpointIdExists() {
    	global $wpdb;
    	$table_name = $wpdb->prefix . $this->optimum_api_table;
		$sqlCheck = "select MAX(id) as id,MAX(page) as page from " . $table_name;
        $resCheck = $wpdb->get_results($sqlCheck);
        /*echo "<pre>";
        print_r($resCheck);
        echo $rowcount = $resCheck->num_rows;
    	exit("test");*/

        if( empty($resCheck[0]->id) ) {
			$page = 1;
			//return $cu_startpoint = 0;
			return ( array('startpoint' => 0, 'page' => $page) );
		} else {
			//return $resCheck[0]->id * 10;
			return ( array( 'startpoint' => $resCheck[0]->id * 10, 'page' => $resCheck[0]->page+1) );
		}
	}

/*	public function dropStartpointtable() {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->optimum_api_table;
		$sqlquery = "TRUNCATE TABLE " . $table_name;
		$delres = $wpdb->query($sqlquery);
	}*/

	public function create_products($product) {
		$post_id = wp_insert_post( array(
		    'post_title' => $product['name_item'],
		    'post_status' => 'publish',
		    'post_type' => "product",
		) );
		wp_set_object_terms( $post_id, 'simple', 'product_type' );

		return $post_id;
	}

	public function checkProductByMetaData($meta_key = '', $meta_value = ''){
		if($meta_key != '' && $meta_value != '') {
			$args = array(
				'post_type' => 'product',
			    'meta_query' => array(
			        array(
			            'key' => $meta_key,
			            'value' => $meta_value,
			            'compare' => '=',
			        )
			    )
			);
			$query = new WP_Query($args);
			$results = $query->posts;
			if(!empty($results)){
				return $results[0]->ID;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public function UpdateProductMetas($post_id, $product) {

		update_post_meta( $post_id, '_visibility', 'visible' );
		update_post_meta( $post_id, '_stock_status', 'instock');
		update_post_meta( $post_id, 'total_sales', '0' );
		update_post_meta( $post_id, '_downloadable', 'no' );
		update_post_meta( $post_id, '_virtual', 'no' );
		update_post_meta( $post_id, '_regular_price', $product['Sale_Price'] );
		update_post_meta( $post_id, '_sale_price', '' );
		update_post_meta( $post_id, '_purchase_note', '' );
		update_post_meta( $post_id, '_featured', 'no' );
		update_post_meta( $post_id, '_weight', '' );
		update_post_meta( $post_id, '_length', '' );
		update_post_meta( $post_id, '_width', '' );
		update_post_meta( $post_id, '_height', '' );

		if( is_array($product['id_Barcod']) && empty($product['id_Barcod']) ) {
			update_post_meta( $post_id, '_sku', $post_id );	
		} else {
			update_post_meta( $post_id, '_sku', $product['id_Barcod'] );	
		}
		
		update_post_meta( $post_id, '_product_attributes', array() );
		update_post_meta( $post_id, '_sale_price_dates_from', '' );
		update_post_meta( $post_id, '_sale_price_dates_to', '' );
		update_post_meta( $post_id, '_price', $product['Sale_Price'] );
		update_post_meta( $post_id, '_sold_individually', '' );
		update_post_meta( $post_id, '_manage_stock', 'yes' );
		update_post_meta( $post_id, '_backorders', 'no' );
		update_post_meta( $post_id, '_stock', $product['Limited_quantity'] );

		update_post_meta( $post_id, '_id_code', $product['id_code'] );						
		update_post_meta( $post_id, '_id_Department', $product['id_Department'] );						
		update_post_meta( $post_id, '_id_Group', $product['id_Group'] );						
		update_post_meta( $post_id, '_Limited_quantity', $product['Limited_quantity'] );						
		update_post_meta( $post_id, '_Packing_quantity', $product['Packing_quantity'] );						
		update_post_meta( $post_id, '_measure', $product['measure'] );
		update_post_meta( $post_id, '_memo', $product['memo'] );
		update_post_meta( $post_id, '_English_name', $product['English_name'] );
		update_post_meta( $post_id, '_Creation', $product['Creation'] );
		update_post_meta( $post_id, '_update_date', $product['update_date'] );
		update_post_meta( $post_id, '_Locked_item', $product['Locked_item'] );
		update_post_meta( $post_id, '_alut1', $product['alut1'] );
		update_post_meta( $post_id, '_no_tax', $product['no_tax'] );
		update_post_meta( $post_id, '_mchir_neto', $product['mchir_neto'] );
		update_post_meta( $post_id, '_anchat_mchira', $product['anchat_mchira'] );
		update_post_meta( $post_id, '_balances', $product['balances'] );
		update_post_meta( $post_id, '_id_Sub_Group', $product['id_Sub_Group'] );
		update_post_meta( $post_id, '_id_Barcod', $product['id_Barcod'] );
		update_post_meta( $post_id, '_id_kod_nosaf', $product['id_kod_nosaf'] );
		update_post_meta( $post_id, '_id_kod_aviv', $product['id_kod_aviv'] );
	}

	public function getProductUpdateOrderShort($order_id) {
		if(get_post_meta($order_id, 'has_entry_in_optimum', true) == 'yes'){
			return;
		}
		$data = array();
		$order = wc_get_order( $order_id );
		$order_data = $order->get_data();
		$order = new WC_Order( $order_id );
		$items = $order->get_items();
		$line = 0;
		$orderTotal = 0;
		foreach ($order->get_items() as $item_id => $item_data) {
			$line++;
			$data = [];
		    $product = $item_data->get_product();
		    $pr_id = $product->get_id();
		    $data['id_Customer_Optimum'] = 2500;
			$data['enter_user_Optimum'] = 'zaidman1';
			$data['enter_pass_Optimum'] = 'zaidman1';
			$data['store'] = '';
			$data['ID_order'] = $order_id;
		    $data['date_order'] = $order_data['date_created']->date('Y-m-d');
			$data['id_Customer'] = 2;
			$data['line'] = $line;
			$data['id_code'] = get_post_meta( $pr_id, '_id_code', true);
			//$data['id_code_2'] = $pr_id;
			//$data['order_total'] = $order->get_total();
			$data['name_item'] = $product->get_name();
		    $data['quantity'] = $item_data->get_quantity();
		    $data['memo'] = '';
			$data['measure'] = (!is_array(get_post_meta( $pr_id, '_measure', true))) ? get_post_meta( $pr_id, '_measure', true) : '';
		    $data['Sale_Price'] = $product->get_price();
		    $data['Discount_Percent'] = '';
		    $data['total_Payment'] = $item_data->get_total();
		    $orderTotal += floatval($item_data->get_total());
		    $data['situation'] = '';
		    $data['quantity_Provided'] = '';
			$this->Update_order_SHOROT_input($data);
		}

		$Kdata['id_Customer_Optimum'] = 2500;
		$Kdata['enter_user_Optimum'] = 'zaidman1';
		$Kdata['enter_pass_Optimum'] = 'zaidman1';
		$Kdata['Number_order'] = $order_id;
		$Kdata['date_order'] = $order_data['date_created']->date('Y-m-d');
		$Kdata['Round'] = 1;
		$Kdata['day'] = '';
		$Kdata['name_User'] = $order->get_billing_first_name().' '.$order->get_billing_last_name();
		$Kdata['number_line'] = $line;
		$Kdata['total_quantity'] = $order->get_item_count();
		$Kdata['total_Account'] = $orderTotal;
		$Kdata['memo'] = '';
		$Kdata['id_Customer'] = 2;
		if($this->Update_order_KOTERT_input($Kdata)){
			update_post_meta($order_id, 'has_entry_in_optimum', 'yes');
		}
	}

	public function Update_order_SHOROT_input($productData = NULL){
		if($productData != NULL && !empty($productData)){
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "http://myoctopus.co.il/octopus_web/Web_service/WebService_Order.asmx/Update_order_SHOROT_input",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => http_build_query($productData),
			  CURLOPT_HTTPHEADER => array(
			    "Content-Type: application/x-www-form-urlencoded"
			  ),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if(strip_tags($response) == 'Ok'){
				return true;
			}else{
				return false;				
			}
		}
	}

	public function Update_order_KOTERT_input($productData = NULL){
		if($productData != NULL && !empty($productData)){
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "http://myoctopus.co.il/octopus_web/Web_service/WebService_Order.asmx/Update_order_KOTERT_input",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => http_build_query($productData),
			  CURLOPT_HTTPHEADER => array(
			    "Content-Type: application/x-www-form-urlencoded"
			  ),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			if(strip_tags($response) == 'Ok'){
				return true;
			}else{
				return false;				
			}
		}
	}

	public function generateRequestContext($reqFor, $data){
		$contentdata = '';
		$contentstart = '<?xml version="1.0" encoding="utf-8"?>
					<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
						<soap12:Body>';
		$contentstart .= '<'.$reqFor.' xmlns="http://microsoft.com/webservices/">';

		foreach ($data as $key => $value) {
			$contentdata .='<'.$key.'>'.$value.'</'.$key.'>';
		}
		$contentend = '</'.$reqFor.'></soap12:Body></soap12:Envelope>';
		return $contentstart . $contentdata . $contentend;
	}

	public function Generate_Featured_Image( $image_url, $post_id  ){
	    $upload_dir = wp_upload_dir();
	    $image_data = file_get_contents($image_url);
	    $filename = basename($image_url);
	    if(wp_mkdir_p($upload_dir['path']))
	      $file = $upload_dir['path'] . '/' . $filename;
	    else
	      $file = $upload_dir['basedir'] . '/' . $filename;
	    file_put_contents($file, $image_data);

	    $wp_filetype = wp_check_filetype($filename, null );
	    $attachment = array(
	        'post_mime_type' => $wp_filetype['type'],
	        'post_title' => sanitize_file_name($filename),
	        'post_content' => '',
	        'post_status' => 'inherit'
	    );
	    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
	    require_once(ABSPATH . 'wp-admin/includes/image.php');
	    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
	    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
	    $res2= set_post_thumbnail( $post_id, $attach_id );
	}

}

$OptimumOctopus = new OptimumOctopus_WoocommerceSync;